function [F1] = storepoint(pop, minArray)

    F1 = pop(minArray);
    
    


end